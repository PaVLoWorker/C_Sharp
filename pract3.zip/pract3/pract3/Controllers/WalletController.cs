﻿using Microsoft.AspNetCore.Mvc;
using pract3.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace pract3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WalletController : ControllerBase
    {
        List<Wallet> wallets = new List<Wallet>() 
        { 
            new Wallet(){Id = 1, Name = "Guguryk", CountOfMoney = 13 },

            new Wallet(){Id = 3, Name = "lares", CountOfMoney = 10 },

            new Wallet(){Id = 2, Name = "Gec", CountOfMoney = 12 }
        };
        // GET: api/<WalletController>
        [HttpGet]
        public IActionResult Get()
        {
            if(wallets == null)
                return NotFound();
                    
            return Ok(wallets);
        }

        // GET api/<WalletController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                Wallet wallet = wallets.First(W => W.Id == id);
                return Ok(wallet);
            }
            catch (Exception)
            {

                return NotFound();
            }
        }

        // POST api/<WalletController>
        [HttpPost]
        public IActionResult Post([FromBody] Wallet neWwallet)
        {
            if (neWwallet == null)
                return BadRequest();

            wallets.Add(neWwallet);
            return CreatedAtAction(nameof(Get), new {id = neWwallet.Id}, neWwallet);
        }

        // PUT api/<WalletController>/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Wallet newWallet)
        {
            try
            {
                if (newWallet == null)
                    return BadRequest();
                Wallet wallet = wallets.First(W => W.Id == id);

                wallet.Id = id;
                wallet.Name = newWallet.Name;
                wallet.CountOfMoney = newWallet.CountOfMoney;

                return NoContent();
            }
            catch (Exception)
            {

                return NotFound();
            }
        }

        // DELETE api/<WalletController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                Wallet wallet = wallets.First(W => W.Id == id);
                wallets.Remove(wallet);
                return NoContent();
            }
            catch (Exception)
            {
                return NotFound();
            }
        }
    }
}
