﻿namespace pract3.Models
{
    public class Wallet
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public decimal CountOfMoney { get; set; }
    }
}
